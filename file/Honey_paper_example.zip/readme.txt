===================================

 Honey programs and datasets used in the paper:
 
 "Honey: A dataflow programming language for the processing and featurization of multivariate, asynchronous and non-uniformly sampled scalar symbolic time sequences"
 
 Mathieu Guillame-Bert
 mathieug@andrew.cmu.edu 
 
 9 May 2016
 
===================================

This archive contains the datasets, the Honey programs and the Event Viewer configuration for each of the tasks illustrated  in the paper: "Honey: A dataflow programming language for the processing and featurization of multivariate, asynchronous and non-uniformly sampled scalar symbolic time sequences".

To reproduce the results from the paper you need:
	- Honey (a binary is already available for Window 64bits). Note that Honey contains an editor in Honey/bin/HoneyEditor.jar.
	- The /bin directory of Honey to be in the $PATH of your operating system.
	- Event Viewer
	- [Optionnnaly] R and R studio to generate the final plot of the task 4.
	
For each of the four tasks you will find:

- task*_data : A directory containing the dataset for the task. Since task 4 and task 2 use the same dataset, task4_data is empty.

- task*_results : The directory were the results of each task will be saved. For each task, the file task*_results/debug.bin contains the records used to plot the paper's figures.

- task*.hny : The Honey program used to solve the task. To run the program, you can either:
	- Start the Honey editor (call "HoneyEditor" in Honey/bin), open the program and click on "Run" (F5).
	- Or, run the following command in the shell: "honey task*_data.hny" (replace * with the task number).
	
- task*.sce : The event viewer configuration to plot and explore the result of the programs. You need to run the task*.hny programs first. If you change a program and run it, symply press the refresh button in Event Viewer (the two arrows in circle) to update the display. For more details, you can watch the tutorial video of Event Viewer on the Honey website.

- task4_plot.R : A small R script to plot the result of task 4.


The datasets used for each task are real-world datasets:

Task 1
The dataset is a single patient record taken from the dataset from the journal paper "Learning Temporal Rules to Forecast Instability in Continuously Monitored Patients", Mathieu Guillame-Bert, Artur Dubrawski, Donghan Wang, Marilyn Hravnak, Gilles Clermont, Michael R. Pinsky
Journal of the American Medical Informatics Association (JAMIA), 2016.

Task 2 and 4
This dataset is extracted from a larger dataset without any published work yet.

Task 3
The MERL Motion Detector Dataset.
Wren, Christopher R. and Ivanov, Yuri A. and Leigh, Darren and Westhues, Jonathan

To run a task, run the Honey task*.hny program (with the command line e.g. "Honey task1.hny", or with the Honey Editor and pressing F5). Once the program execution is over, use Event Viewer to open the corresponding task*.sce file.
