data = read.table("task4_results/result.csv",header=T)

data = data[-1,]

x = data$begin_expiration_sinceLast.10.T.
y = data$CVP_UDUD_XAYV_Dv_A

plot(x,y
	,xlab="Time to last expiration (s)"
	,ylab="Atrial pressure increase (mmHg)"
	,pch="+"
	,ylim=c(1,5))

s = smooth.spline(x, y, spar=0.6)
lines(s, col='red', lwd=2)

